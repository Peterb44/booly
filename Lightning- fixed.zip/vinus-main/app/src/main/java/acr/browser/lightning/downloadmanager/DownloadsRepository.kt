package acr.browser.lightning.downloadmanager

import acr.browser.lightning.R

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Application
import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.lang.ref.WeakReference
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

/**
 * يدير التنزيلات وسجل روابطها بشكل دائم.
 * Android 10+: يحفظ مباشرة في مجلد Download عبر MediaStore.
 * Android 9 وأقدم: يحفظ في مجلد Download العام.
 */
object DownloadsRepository {

    val downloadList = mutableListOf<DownloadItem>()
    private val downloadEngine = DownloadManagerEngine()
    private val listeners = mutableListOf<() -> Unit>()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var initialized = false
    private var lastSaveTime = 0L
    private const val SAVE_THROTTLE_MS = 1500L
    private const val DEFAULT_CONCURRENT_DOWNLOADS = 1

    /** المسار المخصص للتنزيلات: /storage/emulated/0/DownLS10/ */
    private const val CUSTOM_DOWNLOAD_DIR_NAME = "DownLS10"

    /**
     * يعيد المجلد المخصص للتنزيلات (/storage/emulated/0/DownLS10/).
     * ينشئ المجلد تلقائياً إذا لم يكن موجوداً.
     */
    private fun getCustomDownloadDir(): File {
        val baseDir = Environment.getExternalStoragePublicDirectory("")
        val customDir = File(baseDir, CUSTOM_DOWNLOAD_DIR_NAME)
        if (!customDir.exists()) {
            customDir.mkdirs()
        }
        return customDir
    }

    /** يهيّئ مدير التنزيلات ويتابع النشاط الظاهر لعرض نافذة التأكيد فوق المتصفح. */
    fun initialize(context: Context) {
        trackActivities(context)
        ensureLoaded(context.applicationContext)
    }

    fun ensureLoaded(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences("main_prefs", Context.MODE_PRIVATE)
        val concurrency = prefs.getInt("download_concurrency", DEFAULT_CONCURRENT_DOWNLOADS).coerceIn(1, 10)
        downloadEngine.setMaxConcurrentDownloads(concurrency)

        if (initialized) return
        initialized = true
        downloadList.clear()
        downloadList.addAll(DownloadPersistence.load(context.applicationContext))
    }

    /** يعيد مزامنة القائمة من التخزين إذا كانت الذاكرة فارغة رغم وجود تنزيلات محفوظة. */
    fun restoreListIfEmpty(context: Context) {
        ensureLoaded(context.applicationContext)
        synchronized(downloadList) {
            if (downloadList.isEmpty()) {
                val saved = DownloadPersistence.load(context.applicationContext)
                if (saved.isNotEmpty()) downloadList.addAll(saved)
            }
        }
    }

    fun getMaxConcurrentDownloads(context: Context): Int {
        return context.applicationContext
            .getSharedPreferences("main_prefs", Context.MODE_PRIVATE)
            .getInt("download_concurrency", DEFAULT_CONCURRENT_DOWNLOADS)
            .coerceIn(1, 10)
    }

    fun setMaxConcurrentDownloads(context: Context, count: Int) {
        val value = count.coerceIn(1, 10)
        context.applicationContext
            .getSharedPreferences("main_prefs", Context.MODE_PRIVATE)
            .edit()
            .putInt("download_concurrency", value)
            .apply()
        downloadEngine.setMaxConcurrentDownloads(value)
    }

    fun addListener(listener: () -> Unit) { listeners.add(listener) }
    fun removeListener(listener: () -> Unit) { listeners.remove(listener) }

    private fun notifyChanged(context: Context, forceSave: Boolean = false) {
        mainHandler.post { listeners.toList().forEach { it() } }
        val appContext = context.applicationContext
        mainHandler.post { runCatching { DownloadNotifier.sync(appContext) } }
        val now = System.currentTimeMillis()
        if (forceSave || now - lastSaveTime > SAVE_THROTTLE_MS) {
            lastSaveTime = now
            DownloadPersistence.save(context.applicationContext, downloadList)
        }
    }

    private val probeExecutor = Executors.newCachedThreadPool()

    /**
     * يبدأ أو يستأنف رابطاً. يدعم http/https وdata:، وعند غموض اسم الملف أو نوعه
     * يستكشف استجابة الخادم أولاً (Content-Disposition + Content-Type + التحويلات).
     */
    fun startNewDownload(
        context: Context,
        url: String,
        showToast: Boolean = true,
        suggestedFileName: String? = null,
        userAgent: String? = null,
        referer: String? = null,
        mimeType: String? = null
    ) {
        val appContext = context.applicationContext
        trackActivities(context)
        ensureLoaded(appContext)
        requestNotificationPermissionOnce(context)
        var typed = url.trim()
        if (typed.isEmpty()) return

        if (typed.startsWith("data:", ignoreCase = true)) {
            saveDataUrl(appContext, typed, suggestedFileName, mimeType)
            return
        }
        if (typed.startsWith("magnet:", ignoreCase = true)) {
            openMagnet(appContext, typed)
            return
        }
        if (typed.startsWith("blob:", ignoreCase = true)) {
            toast(appContext, "رابط blob: يُنزَّل من داخل المتصفح فقط، من الصفحة التي أنشأته")
            return
        }
        // رابط بدون بروتوكول (مثل example.com/file.zip): نفترض https
        if (!typed.contains("://") && !typed.startsWith("blob:", ignoreCase = true)) {
            typed = "https://$typed"
        }
        val scheme = typed.substringBefore("://", "").lowercase()
        if (scheme != "http" && scheme != "https" && scheme != "ftp") {
            toast(appContext, "بروتوكول الرابط غير مدعوم (المدعوم: http وhttps وftp)")
            return
        }
        // Terabox: صفحة المشاركة تحتاج تسجيل دخول، ولا يوجد رابط مباشر بدونه
        if (scheme != "ftp" && LinkResolver.isTeraboxSharePage(typed)) {
            toast(appContext, "Terabox: افتح الرابط في المتصفح وسجّل الدخول ثم اضغط زر التنزيل في الصفحة")
            return
        }
        // روابط المشاركة (Google Drive, Dropbox, OneDrive, GitHub...) تتحول إلى روابط تنزيل مباشرة
        val cleanUrl = if (scheme == "ftp") typed else LinkResolver.resolve(typed)

        // يُسجّل رابط الملف الحقيقي سواء أضيف من المتصفح أو من مدير التنزيل +.
        DownloadHistory.add(appContext, cleanUrl)

        val existing = downloadList.find { it.url == cleanUrl }
        if (existing != null) {
            if (existing.state == DownloadState.COMPLETED) {
                if (isFilePresent(appContext, existing)) {
                    toast(appContext, "الملف موجود: ${existing.fileName}")
                    return
                }
                // السجل موجود لكن الملف حُذف من الجهاز: اعتبره تنزيلًا جديدًا.
                downloadList.remove(existing)
            } else {
                if (existing.state == DownloadState.DOWNLOADING) {
                    toast(appContext, "التنزيل قيد التنفيذ")
                    return
                }
                if (!userAgent.isNullOrBlank()) existing.userAgent = userAgent
                if (!referer.isNullOrBlank()) existing.referer = referer
                existing.state = DownloadState.DOWNLOADING
                existing.status = "في الانتظار..."
                existing.speed = "0 KB/s"
                notifyChanged(appContext, forceSave = true)
                executeDownload(appContext, existing)
                return
            }
        }

        if (LinkResolver.needsRemoteResolution(cleanUrl)) {
            // Mega / Yandex Disk / pCloud: نطلب من الموقع الاسم والرابط المباشر أولاً
            probeExecutor.execute {
                try {
                    val link = LinkResolver.resolveRemote(cleanUrl)
                    val remoteName = resolveFileName(
                        suggestedFileName?.takeIf { it.isNotBlank() } ?: link.fileName, null, link.directUrl, mimeType
                    )
                    mainHandler.post { beginNewDownload(appContext, cleanUrl, remoteName, userAgent, referer) }
                } catch (e: Exception) {
                    toast(appContext, "فشل تنزيل الملف: " + (e.message ?: "تعذّر قراءة الرابط"))
                }
            }
            return
        }

        if (scheme == "ftp") {
            // FTP لا توجد فيه ترويسات: الاسم من مسار الرابط
            val ftpName = resolveFileName(suggestedFileName?.takeIf { it.isNotBlank() }, null, cleanUrl, mimeType)
            beginNewDownload(appContext, cleanUrl, ftpName, userAgent, referer)
            return
        }

        // اسم الملف النهائي يُؤخذ من Content-Disposition أولاً، حتى لو كان الرابط
        // نفسه يحتوي اسم ملف مختلفًا.
        val hint = suggestedFileName?.takeIf { it.isNotBlank() } ?: nameFromUrlIfReliable(cleanUrl)
        probeExecutor.execute {
            val info = downloadEngine.probe(cleanUrl, userAgent, referer)
            val name = resolveFileName(hint, info, cleanUrl, mimeType)
            mainHandler.post { beginNewDownload(appContext, cleanUrl, name, userAgent, referer) }
        }
    }

    /** نتيجة تحضير معلومات الملف قبل عرضها على المستخدم (اسم، حجم، امتداد). */
    data class DownloadPreview(
        val fileName: String,
        val totalSize: Long,
        val extension: String
    )

    /** يستحضر معلومات الملف (اسم، حجم، امتداد) دون بدء التنزيل، ثم يستدعي onReady على الخيط الرئيسي. */
    fun probeAndConfirm(
        context: Context,
        url: String,
        suggestedFileName: String? = null,
        userAgent: String? = null,
        referer: String? = null,
        mimeType: String? = null,
        onReady: (DownloadPreview) -> Unit
    ) {
        val appContext = context.applicationContext
        ensureLoaded(appContext)
        var typed = url.trim()
        if (!typed.contains("://")) typed = "https://$typed"
        probeExecutor.execute {
            val info = downloadEngine.probe(typed, userAgent, referer)
            val hint = suggestedFileName?.takeIf { it.isNotBlank() } ?: nameFromUrlIfReliable(typed)
            val name = resolveFileName(hint, info, typed, mimeType)
            val ext = name.substringAfterLast(".", "bin")
            val isHls = typed.substringBefore('?').substringBefore('#')
                .endsWith(".m3u8", ignoreCase = true) ||
                info?.contentType?.contains("mpegurl", ignoreCase = true) == true ||
                ext.equals("m3u8", ignoreCase = true)
            // حجم m3u8 هو حجم قائمة التشغيل فقط، وليس حجم الفيديو؛ اجمع أحجام المقاطع.
            val size = if (isHls) {
                downloadEngine.probeHlsTotalSize(info?.finalUrl ?: typed, userAgent, referer)
            } else {
                info?.contentLength ?: -1L
            }
            mainHandler.post { onReady(DownloadPreview(name, size, ext)) }
        }
    }

    /** يبدأ مسار التنزيل من المتصفح بعد إظهار نافذة تأكيد DownLS10 الأصلية. */
    fun confirmAndStartDownload(
        context: Context,
        url: String,
        suggestedFileName: String? = null,
        userAgent: String? = null,
        referer: String? = null,
        mimeType: String? = null
    ) {
        trackActivities(context)
        val typed = url.trim()
        if (typed.isBlank()) return

        val showConfirmation: (DownloadPreview) -> Unit = { preview ->
            val activity = topActivity?.get()
            if (activity == null || activity.isFinishing ||
                (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && activity.isDestroyed)
            ) {
                toast(context.applicationContext, "تعذّر عرض نافذة تأكيد التنزيل")
            } else {
                val sizeText = if (preview.totalSize >= 0L) {
                    val bytes = preview.totalSize
                    if (bytes < 1024L) "$bytes B" else {
                        val units = arrayOf("KB", "MB", "GB", "TB", "PB", "EB")
                        var amount = bytes.toDouble() / 1024.0
                        var unit = 0
                        while (amount >= 1024.0 && unit < units.lastIndex) {
                            amount /= 1024.0
                            unit++
                        }
                        String.format(java.util.Locale.US, if (amount < 10.0) "%.2f %s" else "%.1f %s", amount, units[unit])
                    }
                } else "حجم غير معروف"

                val dialogView = activity.layoutInflater.inflate(R.layout.dialog_download_confirm, null)
                dialogView.findViewById<TextView>(R.id.tvFileName).text = preview.fileName
                dialogView.findViewById<TextView>(R.id.tvFileSize).text = sizeText
                dialogView.findViewById<TextView>(R.id.tvFileExt).text = preview.extension.ifBlank { "-" }

                val dialog = AlertDialog.Builder(activity)
                    .setView(dialogView)
                    .setCancelable(true)
                    .create()

                dialogView.findViewById<android.widget.Button>(R.id.btnAdd).setOnClickListener {
                    addDownloadItemOnly(
                        activity, typed, preview.fileName, userAgent, referer, preview.totalSize
                    )
                    dialog.dismiss()
                }
                dialogView.findViewById<android.widget.Button>(R.id.btnDownload).setOnClickListener {
                    startNewDownload(
                        activity, typed, showToast = true, suggestedFileName = preview.fileName,
                        userAgent = userAgent, referer = referer, mimeType = mimeType
                    )
                    dialog.dismiss()
                }
                dialogView.findViewById<android.widget.Button>(R.id.btnCancel).setOnClickListener {
                    dialog.dismiss()
                }
                dialog.show()
            }
        }

        if (typed.startsWith("data:", ignoreCase = true)) {
            val dataMime = typed.substringAfter("data:", "").substringBefore(";").substringBefore(",")
                .ifBlank { mimeType ?: "application/octet-stream" }
            val extension = extensionForMime(dataMime) ?: "bin"
            val name = suggestedFileName?.takeIf { it.isNotBlank() }
                ?: "download_${System.currentTimeMillis()}.$extension"
            mainHandler.post { showConfirmation(DownloadPreview(name, -1L, name.substringAfterLast(".", extension))) }
            return
        }

        probeAndConfirm(context, typed, suggestedFileName, userAgent, referer, mimeType, showConfirmation)
    }

    /** يضيف عنصر تنزيل إلى القائمة بحالة "في الانتظار" بدون بدء التحميل الفعلي. */
    fun addDownloadItemOnly(
        context: Context,
        cleanUrl: String,
        fileName: String,
        userAgent: String? = null,
        referer: String? = null,
        totalBytes: Long = 0L
    ): DownloadItem? {
        val appContext = context.applicationContext
        trackActivities(context)
        ensureLoaded(appContext)

        if (downloadList.any { it.url == cleanUrl && it.state == DownloadState.DOWNLOADING }) {
            toast(appContext, "التنزيل قيد التنفيذ")
            return null
        }
        val knownInList = downloadList.any { it.fileName == fileName && isFilePresent(appContext, it) }
        if (knownInList || isFileNamePresentInDownload(appContext, fileName)) {
            toast(appContext, "الملف موجود: $fileName")
            return null
        }

        val ext = fileName.substringAfterLast(".", "bin")
        val item = DownloadItem(
            id = System.currentTimeMillis(),
            url = cleanUrl,
            fileName = fileName,
            extension = ext,
            totalBytes = totalBytes.coerceAtLeast(0L),
            userAgent = userAgent,
            referer = referer,
            status = "في الانتظار...",
            state = DownloadState.PAUSED
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val uri = createPendingDownload(appContext, item.fileName)
            if (uri == null) {
                toast(appContext, "تعذّر إنشاء ملف التنزيل داخل Download")
                return null
            }
            val actualName = queryDisplayName(appContext.contentResolver, uri)
            if (actualName != null && isAutoRenamedCopy(fileName, actualName)) {
                deleteUriQuietly(appContext.contentResolver, uri)
                toast(appContext, "الملف موجود: $fileName")
                return null
            }
            item.localUri = uri.toString()
        }

        downloadList.add(0, item)
        notifyChanged(appContext, forceSave = true)
        toast(appContext, "أضيف الملف إلى التنزيلات: ${item.fileName}")
        return item
    }

    /** روابط magnet تُسلَّم لتطبيق تورنت مثبّت على الجهاز (المدير الحالي لا يحتوي محرك BitTorrent). */
    private fun openMagnet(appContext: Context, magnet: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(magnet)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            appContext.startActivity(intent)
            toast(appContext, "تم إرسال رابط magnet إلى تطبيق التورنت")
        } catch (e: Exception) {
            toast(appContext, "لا يوجد تطبيق تورنت على الجهاز لفتح رابط magnet")
        }
    }

    private var askedNotificationPermission = false

    /** من أندرويد 13 يلزم إذن الإشعارات ليظهر إشعار التنزيل: نطلبه مرة واحدة. */
    private fun requestNotificationPermissionOnce(context: Context) {
        if (askedNotificationPermission || Build.VERSION.SDK_INT < 33 || context !is Activity) return
        askedNotificationPermission = true
        try {
            if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                context.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7301)
            }
        } catch (e: Exception) { }
    }

    /** هل يمكن استئناف هذا التنزيل من الشبكة؟ (ملفات blob/data المحلية لا يمكن استئنافها) */
    fun isResumable(item: DownloadItem): Boolean {
        val u = item.url.lowercase()
        return u.startsWith("http://") || u.startsWith("https://") || u.startsWith("ftp://")
    }

    /** إيقاف مؤقت لكل التنزيلات الجارية (زر الإشعار). */
    fun pauseAll(context: Context) {
        ensureLoaded(context.applicationContext)
        downloadList.filter { it.state == DownloadState.DOWNLOADING }.forEach { pauseDownload(context, it) }
    }

    /** استئناف كل التنزيلات المتوقفة مؤقتاً (زر الإشعار). */
    fun resumeAll(context: Context) {
        ensureLoaded(context.applicationContext)
        downloadList.filter { it.state == DownloadState.PAUSED && isResumable(it) }.forEach { resumeDownload(context, it) }
    }

    /** بعد إنهاء النظام للعملية: يكمل التنزيلات التي كانت جارية وقتها. */
    fun resumeInterrupted(context: Context) {
        ensureLoaded(context.applicationContext)
        val ids = DownloadPersistence.interruptedIds
        DownloadPersistence.interruptedIds = emptySet()
        downloadList.filter { it.id in ids && it.state == DownloadState.PAUSED && isResumable(it) }
            .forEach { resumeDownload(context, it) }
    }

    /** ينشئ عنصر التنزيل ويبدأه بعد أن أصبح اسم الملف معروفاً. يعمل على الخيط الرئيسي. */
    private fun beginNewDownload(
        appContext: Context,
        cleanUrl: String,
        fileName: String,
        userAgent: String?,
        referer: String?
    ) {
        // ضغطتَ على الرابط مرتين أثناء الاستكشاف
        if (downloadList.any { it.url == cleanUrl && it.state == DownloadState.DOWNLOADING }) {
            toast(appContext, "التنزيل قيد التنفيذ")
            return
        }

        // إذا كان نفس اسم الملف موجوداً فعلياً في Download، لا ننشئ نسخة ثانية.
        val knownInList = downloadList.any { it.fileName == fileName && isFilePresent(appContext, it) }
        if (knownInList || isFileNamePresentInDownload(appContext, fileName)) {
            toast(appContext, "الملف موجود: $fileName")
            return
        }

        val ext = fileName.substringAfterLast(".", "bin")
        val item = DownloadItem(
            id = System.currentTimeMillis(),
            url = cleanUrl,
            fileName = fileName,
            extension = ext,
            userAgent = userAgent,
            referer = referer
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val uri = createPendingDownload(appContext, item.fileName)
            if (uri == null) {
                toast(appContext, "تعذّر إنشاء ملف التنزيل داخل Download")
                return
            }
            // إذا كان في Download ملف بنفس الاسم لا يستطيع التطبيق رؤيته، يعيد النظام تسمية الملف الجديد تلقائيًا
            // إلى «الاسم (1).امتداد». نكتشف ذلك ونلغي التنزيل بدل إنشاء نسخة مكررة.
            val actualName = queryDisplayName(appContext.contentResolver, uri)
            if (actualName != null && isAutoRenamedCopy(fileName, actualName)) {
                deleteUriQuietly(appContext.contentResolver, uri)
                toast(appContext, "الملف موجود: $fileName")
                return
            }
            item.localUri = uri.toString()
        }

        downloadList.add(0, item)
        notifyChanged(appContext, forceSave = true)
        toast(appContext, "بدأ تنزيل الملف: ${item.fileName}")
        executeDownload(appContext, item)
    }

    // ---------------- تحديد اسم الملف ونوعه ----------------

    private val dynamicExtensions = setOf("php", "asp", "aspx", "jsp", "cgi", "do", "action", "ashx", "axd", "pl")

    /** هل للاسم امتداد حقيقي (حرفان/أرقام حتى 8 خانات)؟ */
    private fun hasUsableExtension(name: String): Boolean {
        val dot = name.lastIndexOf('.')
        if (dot <= 0 || dot == name.length - 1) return false
        val ext = name.substring(dot + 1)
        return ext.length in 1..8 && ext.all { it.isLetterOrDigit() }
    }

    private fun extensionOf(name: String): String =
        if (hasUsableExtension(name)) name.substringAfterLast('.').lowercase() else ""

    /** آخر جزء من مسار الرابط كاسم محتمل (بعد فك الترميز)، أو null. */
    private fun lastSegmentName(url: String): String? {
        return try {
            val seg = Uri.parse(url).lastPathSegment ?: return null
            val decoded = Uri.decode(seg).trim()
            if (decoded.isEmpty()) null else decoded
        } catch (e: Exception) {
            null
        }
    }

    /** اسم من الرابط كمرجع محتمل للملف (حتى لو لم يكن له امتداد معروف). */
    private fun nameFromUrlIfReliable(url: String): String? {
        val name = lastSegmentName(url) ?: return null
        if (extensionOf(name) in dynamicExtensions) return null
        return name
    }

    // امتدادات إضافية للأنواع الشائعة التي لا تتعرف عليها MimeTypeMap على بعض إصدارات Android.
    // هذا الجدول يحدد اسم الملف فقط ولا يغيّر إعدادات التنزيل أو طريقة نقل البيانات.
    private val mimeExtensionOverrides = mapOf(
        "application/x-zip-compressed" to "zip",
        "application/zip" to "zip",
        "application/x-rar-compressed" to "rar",
        "application/vnd.rar" to "rar",
        "application/x-7z-compressed" to "7z",
        "application/x-msdownload" to "exe",
        "application/vnd.microsoft.portable-executable" to "exe",
        "application/x-bittorrent" to "torrent",
        "application/x-gzip" to "gz",
        "application/gzip" to "gz",
        "application/x-tar" to "tar",
        "application/x-bzip2" to "bz2",
        "application/x-xz" to "xz",
        "application/x-iso9660-image" to "iso",
        "application/vnd.android.package-archive" to "apk",
        "application/vnd.android.obb" to "obb",
        "application/pdf" to "pdf",
        "application/epub+zip" to "epub",
        "application/rtf" to "rtf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document" to "docx",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" to "xlsx",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation" to "pptx",
        "application/msword" to "doc",
        "application/vnd.ms-excel" to "xls",
        "application/vnd.ms-powerpoint" to "ppt",
        "application/vnd.oasis.opendocument.text" to "odt",
        "application/vnd.oasis.opendocument.spreadsheet" to "ods",
        "application/vnd.oasis.opendocument.presentation" to "odp",
        "application/json" to "json",
        "application/xml" to "xml",
        "application/x-yaml" to "yaml",
        "application/yaml" to "yaml",
        "application/x-sqlite3" to "sqlite",
        "application/vnd.sqlite3" to "sqlite",
        "application/octet-stream" to "bin",
        "binary/octet-stream" to "bin",
        "text/plain" to "txt",
        "text/csv" to "csv",
        "text/markdown" to "md",
        "text/html" to "html",
        "text/xml" to "xml",
        "image/svg+xml" to "svg",
        "image/heic" to "heic",
        "image/heif" to "heif",
        "image/avif" to "avif",
        "audio/flac" to "flac",
        "audio/aac" to "aac",
        "audio/ogg" to "ogg",
        "audio/midi" to "mid",
        "video/x-matroska" to "mkv",
        "video/x-msvideo" to "avi",
        "video/3gpp" to "3gp"
    )

    private fun extensionForMime(mime: String?): String? {
        val m = mime?.substringBefore(';')?.trim()?.lowercase()
        if (m.isNullOrEmpty() || m == "application/octet-stream" || m == "binary/octet-stream") return null
        return mimeExtensionOverrides[m] ?: MimeTypeMap.getSingleton().getExtensionFromMimeType(m)
    }

    /** يجمع اسم الملف النهائي من: الاسم المقترح، Content-Disposition، الرابط النهائي، ونوع المحتوى. */
    private fun resolveFileName(hint: String?, info: ProbeInfo?, originalUrl: String, mimeHint: String?): String {
        var name: String? = null
        if (info != null) name = fileNameFromContentDispositionOrNull(info.contentDisposition)
        if (name == null) name = hint?.takeIf { it.isNotBlank() }
        if (name == null) name = lastSegmentName(info?.finalUrl ?: originalUrl) ?: lastSegmentName(originalUrl)
        if (name == null) name = "file_${System.currentTimeMillis()}"
        name = sanitizeFileName(name)

        val mime = (info?.contentType ?: mimeHint)?.substringBefore(';')?.trim()?.lowercase()
        val mimeExt = extensionForMime(mime)
        val currentExt = extensionOf(name)
        if (currentExt.isEmpty()) {
            name = "$name.${mimeExt ?: "bin"}"
        } else if (currentExt in dynamicExtensions && mimeExt != null && mime != "text/html") {
            // مثل get.php يرجع ملف zip فعلياً
            name = name.substringBeforeLast('.') + "." + mimeExt
        }
        return name
    }

    // ---------------- ملفات محلية: data: و blob: ----------------

    /** مقبض كتابة لملف يُبنى محلياً (روابط blob: وdata:). */
    class LocalSink internal constructor(
        internal val item: DownloadItem,
        internal val output: OutputStream,
        internal val uri: Uri?,
        internal val file: File?
    ) {
        internal var written = 0L
        internal var lastUiUpdate = 0L
    }

    /** يشغّل الكتلة على الخيط الرئيسي وينتظر نتيجتها (للاستدعاء من خيوط أخرى). */
    private fun <T> runOnMainBlocking(block: () -> T?): T? {
        if (Looper.myLooper() == Looper.getMainLooper()) return block()
        val latch = CountDownLatch(1)
        val result = AtomicReference<T?>(null)
        mainHandler.post {
            try { result.set(block()) } catch (e: Exception) { } finally { latch.countDown() }
        }
        latch.await(10, TimeUnit.SECONDS)
        return result.get()
    }

    /** يفتح ملفاً محلياً في Download ويسجّله في قائمة التنزيلات. يمكن استدعاؤه من أي خيط. */
    fun openLocalSink(context: Context, rawName: String?, mime: String?, totalBytes: Long, label: String): LocalSink? {
        val appContext = context.applicationContext
        return runOnMainBlocking { openLocalSinkOnMain(appContext, rawName, mime, totalBytes, label) }
    }

    private fun openLocalSinkOnMain(
        appContext: Context, rawName: String?, mime: String?, totalBytes: Long, label: String
    ): LocalSink? {
        ensureLoaded(appContext)
        var name = sanitizeFileName(rawName?.takeIf { it.isNotBlank() } ?: "download_${System.currentTimeMillis()}")
        if (!hasUsableExtension(name)) name = "$name.${extensionForMime(mime) ?: "bin"}"

        val knownInList = downloadList.any { it.fileName == name && isFilePresent(appContext, it) }
        if (knownInList || isFileNamePresentInDownload(appContext, name)) {
            toast(appContext, "الملف موجود: $name")
            return null
        }

        val item = DownloadItem(
            id = System.currentTimeMillis(),
            url = label,
            fileName = name,
            extension = name.substringAfterLast('.', "bin"),
            status = "جاري التحميل: 0%"
        )
        var uri: Uri? = null
        var file: File? = null
        var output: OutputStream? = null
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val created = createPendingDownload(appContext, name)
                    ?: throw IllegalStateException("تعذّر إنشاء الملف")
                uri = created
                val actualName = queryDisplayName(appContext.contentResolver, created)
                if (actualName != null && isAutoRenamedCopy(name, actualName)) {
                    deleteUriQuietly(appContext.contentResolver, created)
                    toast(appContext, "الملف موجود: $name")
                    return null
                }
                item.localUri = created.toString()
                output = appContext.contentResolver.openOutputStream(created, "w")
            } else {
                val dir = getCustomDownloadDir()
                val target = File(dir, name)
                file = target
                output = FileOutputStream(target)
            }
        } catch (e: Exception) {
            uri?.let { deleteUriQuietly(appContext.contentResolver, it) }
            toast(appContext, "فشل تنزيل الملف: $name")
            return null
        }
        val out = output
        if (out == null) {
            uri?.let { deleteUriQuietly(appContext.contentResolver, it) }
            toast(appContext, "فشل تنزيل الملف: $name")
            return null
        }

        item.totalBytes = totalBytes
        downloadList.add(0, item)
        notifyChanged(appContext, forceSave = true)
        toast(appContext, "بدأ تنزيل الملف: $name")
        return LocalSink(item, out, uri, file)
    }

    /** يكتب دفعة بيانات في الملف المحلي (يُستدعى من خيط الكتابة، ويحدّث الواجهة على الخيط الرئيسي). */
    fun writeLocalSink(context: Context, sink: LocalSink, data: ByteArray, length: Int) {
        sink.output.write(data, 0, length)
        sink.written += length
        val now = System.currentTimeMillis()
        if (now - sink.lastUiUpdate >= 4000) {
            sink.lastUiUpdate = now
            val written = sink.written
            val appContext = context.applicationContext
            mainHandler.post {
                sink.item.downloadedBytes = written
                if (sink.item.totalBytes > 0) {
                    sink.item.progress = ((written * 100) / sink.item.totalBytes).toInt().coerceIn(0, 100)
                }
                sink.item.status = "جاري التحميل: ${sink.item.progress}%"
                notifyChanged(appContext)
            }
        }
    }

    fun finishLocalSink(context: Context, sink: LocalSink) {
        val appContext = context.applicationContext
        try { sink.output.flush(); sink.output.close() } catch (e: Exception) { }
        mainHandler.post {
            sink.uri?.let { publishDownload(appContext, it) }
            sink.item.downloadedBytes = sink.written
            sink.item.totalBytes = sink.written
            sink.item.progress = 100
            sink.item.speed = "0 KB/s"
            sink.item.status = "مكتمل"
            sink.item.state = DownloadState.COMPLETED
            toast(appContext, "اكتمل تنزيل الملف: ${sink.item.fileName}")
            runCatching { notifyChanged(appContext, forceSave = true) }
        }
    }

    fun failLocalSink(context: Context, sink: LocalSink, message: String?) {
        val appContext = context.applicationContext
        try { sink.output.close() } catch (e: Exception) { }
        sink.uri?.let { deleteUriQuietly(appContext.contentResolver, it) }
        sink.file?.let { runCatching { it.delete() } }
        mainHandler.post {
            sink.item.localUri = null
            sink.item.speed = "0 KB/s"
            sink.item.status = "فشل: ${message ?: "تعذّر التنزيل"}"
            sink.item.state = DownloadState.ERROR
            toast(appContext, "فشل تنزيل الملف: ${sink.item.fileName}")
            runCatching { notifyChanged(appContext, forceSave = true) }
        }
    }

    /** رسالة تظهر 3 ثوانٍ (للاستخدام من الملفات الأخرى). */
    fun showMessage(context: Context, message: String) = toast(context, message)

    /** ينزّل رابط data: (نص أو base64) ويحفظه في Download. */
    fun saveDataUrl(context: Context, dataUrl: String, suggestedName: String?, mimeHint: String?) {
        val appContext = context.applicationContext
        ensureLoaded(appContext)
        Thread {
            try {
                val comma = dataUrl.indexOf(',')
                if (comma < 0) throw IllegalArgumentException("رابط data غير صالح")
                val header = dataUrl.substring(5, comma)
                val isBase64 = header.contains(";base64", ignoreCase = true)
                val mime = header.substringBefore(';').ifBlank { mimeHint ?: "application/octet-stream" }
                val payload = Uri.decode(dataUrl.substring(comma + 1))
                val bytes = if (isBase64) {
                    android.util.Base64.decode(payload, android.util.Base64.DEFAULT)
                } else {
                    payload.toByteArray(Charsets.UTF_8)
                }
                val sink = openLocalSink(appContext, suggestedName, mime, bytes.size.toLong(), "data:$mime")
                if (sink != null) {
                    try {
                        writeLocalSink(appContext, sink, bytes, bytes.size)
                        finishLocalSink(appContext, sink)
                    } catch (e: Exception) {
                        failLocalSink(appContext, sink, e.message)
                    }
                }
            } catch (e: Exception) {
                toast(appContext, "فشل تنزيل الملف${if (suggestedName.isNullOrBlank()) "" else ": $suggestedName"}")
            }
        }.start()
    }

    fun executeDownload(context: Context, item: DownloadItem) {
        val appContext = context.applicationContext
        trackActivities(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val uri = item.localUri?.let { runCatching { Uri.parse(it) }.getOrNull() }
                ?: createPendingDownload(appContext, item.fileName)?.also { item.localUri = it.toString() }
            if (uri == null) {
                item.state = DownloadState.ERROR
                item.status = "فشل: تعذّر إنشاء ملف Download"
                notifyChanged(appContext, forceSave = true)
                return
            }
            downloadEngine.downloadFileToUri(
                item = item,
                contentResolver = appContext.contentResolver,
                uri = uri,
                onProgress = { progress, speed, downloaded, total ->
                    item.progress = progress
                    item.speed = speed
                    item.downloadedBytes = downloaded
                    item.status = "جاري التحميل: $progress%"
                    notifyChanged(appContext)
                },
                onComplete = {
                    toast(appContext, "اكتمل تنزيل الملف: ${item.fileName}")
                    publishDownload(appContext, uri)
                    item.progress = 100
                    item.speed = "0 KB/s"
                    item.status = "مكتمل"
                    item.state = DownloadState.COMPLETED
                    runCatching { notifyChanged(appContext, forceSave = true) }
                },
                onError = { error ->
                    // إن كان فيه بيانات محمّلة نُبقي الملف الجزئي ليكمل من مكانه عند الاستئناف
                    if (item.downloadedBytes <= 0L) {
                        deleteUriQuietly(appContext.contentResolver, uri)
                        item.localUri = null
                    }
                    item.speed = "0 KB/s"
                    item.status = "فشل: $error"
                    item.state = DownloadState.ERROR
                    toast(appContext, "فشل تنزيل الملف: ${item.fileName}")
                    runCatching { notifyChanged(appContext, forceSave = true) }
                }
            )
        } else {
            val saveDir = getCustomDownloadDir()
            downloadEngine.downloadFile(
                item = item,
                saveDir = saveDir,
                onProgress = { progress, speed, downloaded, total ->
                    item.progress = progress
                    item.speed = speed
                    item.downloadedBytes = downloaded
                    item.status = "جاري التحميل: $progress%"
                    notifyChanged(appContext)
                },
                onComplete = {
                    toast(appContext, "اكتمل تنزيل الملف: ${item.fileName}")
                    item.progress = 100
                    item.speed = "0 KB/s"
                    item.status = "مكتمل"
                    item.state = DownloadState.COMPLETED
                    runCatching { notifyChanged(appContext, forceSave = true) }
                },
                onError = { error ->
                    item.speed = "0 KB/s"
                    item.status = "فشل: $error"
                    item.state = DownloadState.ERROR
                    toast(appContext, "فشل تنزيل الملف: ${item.fileName}")
                    runCatching { notifyChanged(appContext, forceSave = true) }
                }
            )
        }
    }

    fun pauseDownload(context: Context, item: DownloadItem) {
        downloadEngine.pauseDownload(item.id)
        item.state = DownloadState.PAUSED
        item.status = "متوقف مؤقتاً"
        item.speed = "0 KB/s"
        notifyChanged(context, forceSave = true)
    }

    fun resumeDownload(context: Context, item: DownloadItem) {
        val appContext = context.applicationContext
        ensureLoaded(appContext)
        // لا تجعل استئناف الملف ينتظر انتهاء تنزيل آخر عند ضبط التزامن على 1.
        downloadEngine.prepareImmediateResume()
        item.state = DownloadState.DOWNLOADING
        item.status = "جارٍ استئناف التنزيل..."
        item.speed = "0 KB/s"
        notifyChanged(appContext, forceSave = true)
        executeDownload(appContext, item)
    }

    /**
     * يعيد تسمية الملف الفعلي ثم يحدّث اسم العنصر المحفوظ في قائمة التنزيلات.
     * لا يسمح بتغيير الاسم أثناء الكتابة في الملف.
     */
    fun renameDownloadFile(context: Context, item: DownloadItem, requestedName: String): Boolean {
        ensureLoaded(context.applicationContext)
        if (item.state == DownloadState.DOWNLOADING) return false

        val newName = sanitizeFileName(requestedName)
        if (newName.isBlank()) return false
        if (newName == item.fileName) return true
        if (downloadList.any { it !== item && it.fileName.equals(newName, ignoreCase = true) }) return false

        val appContext = context.applicationContext
        val resolver = appContext.contentResolver
        val storedUri = item.localUri?.let { runCatching { Uri.parse(it) }.getOrNull() }
        val contentUri = when {
            storedUri?.scheme == "content" -> storedUri
            storedUri?.scheme == "file" -> null
            storedUri?.scheme == null && !item.localUri.isNullOrBlank() -> null
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> findDownloadUriByName(resolver, item.fileName)
            else -> null
        }

        val renamed = if (contentUri != null) {
            // MediaStore يحتفظ بنفس URI بعد تغيير DISPLAY_NAME.
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, newName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeTypeFor(newName))
            }
            runCatching { resolver.update(contentUri, values, null, null) > 0 }.getOrDefault(false)
        } else {
            val source = if (storedUri?.scheme == "file") {
                File(storedUri.path.orEmpty())
            } else if (storedUri?.scheme == null && !item.localUri.isNullOrBlank()) {
                File(item.localUri!!)
            } else {
                File(getCustomDownloadDir(), item.fileName)
            }
            val destination = File(source.parentFile ?: getCustomDownloadDir(), newName)
            !destination.exists() && source.exists() && source.renameTo(destination)
        }

        if (!renamed) return false
        item.fileName = newName
        item.extension = newName.substringAfterLast('.', "").ifBlank { "bin" }
        notifyChanged(appContext, forceSave = true)
        return true
    }

    fun deleteDownload(context: Context, item: DownloadItem, deleteFileOnDisk: Boolean) {
        val appContext = context.applicationContext
        downloadEngine.pauseDownload(item.id)
        // خيار "الحذف من القائمة فقط" يزيل سجل التنزيل دون حذف الملف من التخزين،
        // سواء كان الملف مكتملاً أو جزئياً. الحذف من الجهاز يحدث فقط عند طلبه صراحةً.
        if (deleteFileOnDisk) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                item.localUri?.let { uriString ->
                    runCatching { appContext.contentResolver.delete(Uri.parse(uriString), null, null) }
                }
            } else {
                val file = File(getCustomDownloadDir(), item.fileName)
                if (file.exists()) file.delete()
            }
        }
        downloadList.remove(item)
        notifyChanged(appContext, forceSave = true)
    }

    /** يتحقق من وجود الملف فعلياً في Download، وليس فقط وجود السجل. */
    fun isFilePresent(context: Context, item: DownloadItem): Boolean {
        if (item.state != DownloadState.COMPLETED) return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val uri = item.localUri?.let { runCatching { Uri.parse(it) }.getOrNull() }
            if (uri != null) {
                runCatching {
                    context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns._ID), null, null, null)?.use { it.moveToFirst() } == true
                }.getOrDefault(false)
            } else {
                findDownloadUriByName(context.contentResolver, item.fileName) != null
            }
        } else {
            File(getCustomDownloadDir(), item.fileName).exists()
        }
    }

    private fun createPendingDownload(context: Context, fileName: String): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val resolver = context.contentResolver
        val mime = mimeTypeFor(fileName)

        fun values(type: String, includeRelativePath: Boolean = true): ContentValues =
            ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, type)
                if (includeRelativePath) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, CUSTOM_DOWNLOAD_DIR_NAME + "/")
                }
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }

        // بعض أجهزة Android 10/ROMs لا تتعامل مع مسار MediaStore واحد بشكل ثابت.
        // نجرب مجموعتي Downloads و Files، مع وبدون RELATIVE_PATH، ثم المسار القديم
        // الخاص بـ Downloads، حتى لا يفشل إنشاء الملف بعد موافقة المستخدم على التنزيل.
        val attempts = listOf<() -> Uri?>(
            { resolver.insert(MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values(mime)) },
            { resolver.insert(MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values("application/octet-stream")) },
            { resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values(mime)) },
            { resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values("application/octet-stream")) },
            { resolver.insert(MediaStore.Files.getContentUri("external"), values(mime)) },
            { resolver.insert(MediaStore.Files.getContentUri("external"), values("application/octet-stream")) },
            { resolver.insert(MediaStore.Files.getContentUri("external"), values(mime, includeRelativePath = false)) },
            { resolver.insert(MediaStore.Files.getContentUri("external"), values("application/octet-stream", includeRelativePath = false)) },
            { resolver.insert(MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values(mime, includeRelativePath = false)) },
            { resolver.insert(MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values("application/octet-stream", includeRelativePath = false)) }
        )

        for (attempt in attempts) {
            val uri = runCatching { attempt() }.getOrNull()
            if (uri != null) return uri
        }
        return null
    }
    private fun publishDownload(context: Context, uri: Uri) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        val values = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        runCatching { context.contentResolver.update(uri, values, null, null) }
    }

    private fun deleteUriQuietly(resolver: ContentResolver, uri: Uri) {
        runCatching { resolver.delete(uri, null, null) }
    }

    private fun findDownloadUriByName(resolver: ContentResolver, fileName: String): Uri? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return null
        val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        return resolver.query(
            collection,
            arrayOf(MediaStore.MediaColumns._ID),
            "${MediaStore.MediaColumns.DISPLAY_NAME} = ?",
            arrayOf(fileName),
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                ContentUris.withAppendedId(collection, cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)))
            } else null
        }
    }

    private fun mimeTypeFor(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun sanitizeFileName(name: String): String {
        // لا تستخدم Regex هنا حتى لا تتأثر الأحرف السليمة بتعبير \r\n.
        // نبدّل فقط محارف أسماء الملفات غير المسموح بها ونحافظ على الاسم الحقيقي.
        val invalid = charArrayOf('\\', '/', ':', '*', '?', '"', '<', '>', '|', '\r', '\n')
        val builder = StringBuilder(name.length)
        for (ch in name.trim()) {
            builder.append(if (ch.code < 32 || invalid.contains(ch)) '_' else ch)
        }
        val cleaned = builder.toString().trim()
        return if (cleaned.isNotEmpty()) cleaned.take(180) else "file_" + System.currentTimeMillis() + ".bin"
    }
    /** يستخرج الاسم المقترح من Content-Disposition أو يعود لاسم الرابط. */
    fun fileNameFromContentDisposition(contentDisposition: String?, url: String): String {
        return fileNameFromContentDispositionOrNull(contentDisposition) ?: extractFileName(url)
    }

    /** الاسم من ترويسة Content-Disposition فقط، أو null إن لم توجد. */
    fun fileNameFromContentDispositionOrNull(contentDisposition: String?): String? {
        if (contentDisposition.isNullOrBlank()) return null
        val star = Regex("""filename\*\s*=\s*([^'";]*)'[^']*'([^;]+)""", RegexOption.IGNORE_CASE)
            .find(contentDisposition)
        if (star != null) {
            val charset = star.groupValues[1].ifBlank { "UTF-8" }
            val raw = star.groupValues[2].trim().trim('"')
            val decoded = runCatching {
                java.net.URLDecoder.decode(raw.replace("+", "%2B"), charset)
            }.getOrDefault(raw)
            if (decoded.isNotBlank()) return sanitizeFileName(decoded)
        }
        val quoted = Regex("""filename\s*=\s*"([^"]+)"""", RegexOption.IGNORE_CASE)
            .find(contentDisposition)?.groupValues?.getOrNull(1)
        if (!quoted.isNullOrBlank()) return sanitizeFileName(quoted)
        val plain = Regex("""filename\s*=\s*([^;]+)""", RegexOption.IGNORE_CASE)
            .find(contentDisposition)?.groupValues?.getOrNull(1)?.trim()
        if (!plain.isNullOrBlank()) return sanitizeFileName(plain)
        return null
    }

    private fun queryDisplayName(resolver: ContentResolver, uri: Uri): String? {
        return runCatching {
            resolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()
    }

    /** هل actualName هو نفس requestedName بعد أن أضاف النظام رقمًا مثل: file (1).zip */
    private fun isAutoRenamedCopy(requestedName: String, actualName: String): Boolean {
        if (actualName == requestedName) return false
        val dot = requestedName.lastIndexOf('.')
        val base = if (dot > 0) requestedName.substring(0, dot) else requestedName
        val ext = if (dot > 0) requestedName.substring(dot) else ""
        return Regex(Regex.escape(base) + " \\(\\d+\\)" + Regex.escape(ext)).matches(actualName)
    }

    private fun isFileNamePresentInDownload(context: Context, fileName: String): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            findDownloadUriByName(context.contentResolver, fileName) != null ||
                File(getCustomDownloadDir(), fileName).exists()
        } else {
            File(getCustomDownloadDir(), fileName).exists()
        }
    }

    private fun extractFileName(url: String): String {
        return try {
            val pathName = Uri.parse(url).lastPathSegment ?: ""
            val decoded = Uri.decode(pathName).substringBefore("?").trim()
            val cleaned = decoded.replace(Regex("[\\/:*?\"<>|]"), "_")
            if (cleaned.isNotEmpty() && cleaned.contains('.')) cleaned.take(180)
            else "file_${System.currentTimeMillis()}.bin"
        } catch (_: Exception) {
            "file_${System.currentTimeMillis()}.bin"
        }
    }

    private const val TOAST_DURATION_MS = 3000L
    private var currentToast: Toast? = null
    private var bannerView: TextView? = null
    private var topActivity: WeakReference<Activity>? = null
    private var lifecycleRegistered = false
    private val hideMessageRunnable = Runnable { hideMessage() }

    /** نتتبع الشاشة المفتوحة حاليًا لنعرض الرسائل فوقها بشكل مضمون. */
    private fun trackActivities(context: Context) {
        if (context is Activity) topActivity = WeakReference(context)
        if (lifecycleRegistered) return
        val app = context.applicationContext as? Application ?: return
        lifecycleRegistered = true
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityResumed(activity: Activity) { topActivity = WeakReference(activity) }
            override fun onActivityPaused(activity: Activity) {
                if (topActivity?.get() === activity) {
                    hideMessage()
                    topActivity = null
                }
            }
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityStarted(activity: Activity) {}
            override fun onActivityStopped(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
    }

    private fun hideMessage() {
        mainHandler.removeCallbacks(hideMessageRunnable)
        currentToast?.cancel()
        currentToast = null
        bannerView?.let { v -> (v.parent as? ViewGroup)?.removeView(v) }
        bannerView = null
    }

    /** شريط رسالة داخل التطبيق فوق كل الواجهة (يظهر دائمًا حتى لو كانت رسائل Toast معطّلة في الجهاز). */
    private fun showBanner(activity: Activity, message: String): Boolean {
        return try {
            val root = activity.findViewById<ViewGroup>(android.R.id.content) ?: return false
            val dp = activity.resources.displayMetrics.density
            val tv = TextView(activity).apply {
                text = message
                setTextColor(Color.WHITE)
                textSize = 15f
                gravity = Gravity.CENTER
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.MIDDLE
                setPadding((18 * dp).toInt(), (12 * dp).toInt(), (18 * dp).toInt(), (12 * dp).toInt())
                background = GradientDrawable().apply {
                    setColor(0xEE323232.toInt())
                    cornerRadius = 24 * dp
                }
                elevation = 24 * dp
            }
            val lp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply {
                bottomMargin = (90 * dp).toInt()
                leftMargin = (24 * dp).toInt()
                rightMargin = (24 * dp).toInt()
            }
            root.addView(tv, lp)
            bannerView = tv
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * كل الرسائل تظهر 3 ثوانٍ بالضبط وتحلّ محل أي رسالة سابقة.
     * إن كان التطبيق مفتوحًا تظهر كشريط داخل الشاشة، وإلا تظهر كرسالة Toast.
     */
    private fun toast(context: Context, message: String) {
        mainHandler.post {
            hideMessage()
            val activity = topActivity?.get()
            val shown = activity != null && !activity.isFinishing && showBanner(activity, message)
            if (!shown) {
                val t = Toast.makeText(context.applicationContext, message, Toast.LENGTH_LONG)
                currentToast = t
                t.show()
            }
            mainHandler.postDelayed(hideMessageRunnable, TOAST_DURATION_MS)
        }
    }
}
